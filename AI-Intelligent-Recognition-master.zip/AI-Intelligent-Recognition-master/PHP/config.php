<?php
/*
☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆
☆                                                                         ☆
☆  系 统：AI智能识物                                                        ☆
☆  日 期：2019-07                                                          ☆
☆  开 发：草札(www.caozha.com)                                              ☆
☆  鸣 谢：穷店(www.qiongdian.com) 品络(www.pinluo.com)                      ☆
☆  声 明: 使用本程序源码必须保留此版权声明等相关信息！                            ☆
☆  Copyright ©2020 www.caozha.com All Rights Reserved.                    ☆
☆                                                                         ☆
☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆
*/


$client_id = 'YgcbU*******S5D4F6';  //你的百度AI应用的Api Key
$client_secret = 'uQy6S**********eutL10Bj7';  //你的百度AI应用的Secret Key

//API可以去百度AI申请：http://ai.baidu.com/   创建账户后，在图像识别创建一个应用
//技术文档：http://ai.baidu.com/ai-doc/REFERENCE/Ck3dwjhhu
